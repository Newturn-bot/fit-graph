# FitGraph demo (MemMachine + Neo4j)

This is a small demo that integrates a simulated MemMachine (MemVerge) insight extractor with a Neo4j graph database to store user body-attribute constraints and check fit risk for products.

Requirements
- Python 3.8+
- Dependencies in `requirements.txt` (recommended to install in a venv):

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r ~/Desktop/requirements.txt
```

Running
- Non-interactive (recommended for scripts or CI):

```bash
# replace with your real password
printf '\n\n\n' | NEO4J_PASSWORD='your_password_here' python3 "/Users/nambeleberthab/Desktop/fitgraph_complete_integratio.py" --auto
```

- Interactive (press ENTER between steps):

```bash
export NEO4J_PASSWORD='your_password_here'
python3 "/Users/nambeleberthab/Desktop/fitgraph_complete_integratio.py"
```

Optional
- You can create a `.env` file in the same directory with NEO4J_PASSWORD and other settings; the script will attempt to load it if `python-dotenv` is installed.

Notes
- The script uses the Neo4j python driver. Ensure your Neo4j instance allows the provided URI and credentials.
- The `--auto` (or `-a`) flag skips prompts so the script runs end-to-end without manual input.
