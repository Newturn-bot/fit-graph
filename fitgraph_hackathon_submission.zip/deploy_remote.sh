#!/usr/bin/env bash
# Small wrapper to copy repo files to a remote server and run the provided deploy.sh there.
# Usage: ./deploy_remote.sh user@host /remote/path

set -eu
if [ "$#" -lt 2 ]; then
  echo "Usage: $0 user@host /remote/path"
  exit 2
fi

REMOTE="$1"
REMOTE_PATH="$2"

FILES=(fitgraph_complete_integration.py requirements.txt Dockerfile docker-compose.yml deploy.sh .env.example README.md)

echo "Copying files to ${REMOTE}:${REMOTE_PATH}..."
for f in "${FILES[@]}"; do
  scp "$f" "${REMOTE}:${REMOTE_PATH}/"
done

echo "Running deploy on remote host..."
ssh "$REMOTE" "cd ${REMOTE_PATH} && chmod +x deploy.sh && ./deploy.sh"

echo "Remote deploy finished. Check logs on remote with: ssh ${REMOTE} 'cd ${REMOTE_PATH} && docker-compose logs -f'"
